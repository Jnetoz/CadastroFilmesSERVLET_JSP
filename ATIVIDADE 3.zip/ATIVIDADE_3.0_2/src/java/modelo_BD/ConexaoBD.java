/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo_BD;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import modelo_Objetos.Filme;

public class ConexaoBD {

    
    public static Connection conectar() 
    {    
        Connection conn = null;
        try 
        { 
            Class.forName("com.mysql.cj.jdbc.Driver");

            
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbfilmes", 
                                              "AplicacaoDW", 
                                           "AplicacaoDW123");
            System.out.println("Conexão bem sucedida.");
        } 
        catch (SQLException ex) 
        {
            System.out.println("Erro ao conectar com o BD -> "+ex);
        } 
        catch (ClassNotFoundException ex) 
        {
            System.out.println("Erro: Driver do BD não encontrado.");
        }

        return conn;
    }

    
    
    public static void desconectar(Connection conn) 
    {
        try 
        {
            if(conn != null && !conn.isClosed()) 
            {
              conn.close();
              System.out.println("Desconectou do banco de dados.");
            }
        } catch (SQLException ex) 
        {
            System.out.println("Não conseguiu desconectar do BD.");
        }
    }













}






/*public static void Conectar() {

    System.out.println("Conectando ao banco...");
    try 
    {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con =  DriverManager.getConnection("jdbc:mysql://127.0.0.1/mysql","AplicacaoTesteJSP","password");
        System.out.println("Conectado.");
    } 
    catch (ClassNotFoundException ex) 
    {
        System.out.println("Classe não encontrada, adicione o driver nas bibliotecas.");
        Logger.getLogger(ConexaoBD.class.getName()).log(Level.SEVERE, null, ex);
    } 
    catch(SQLException e) 
    {
        System.out.println(e);
        throw new RuntimeException(e);
    }
}*/