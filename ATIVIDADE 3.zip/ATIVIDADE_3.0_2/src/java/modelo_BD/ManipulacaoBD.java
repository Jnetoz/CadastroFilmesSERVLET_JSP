/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package modelo_BD;
import java.sql.*;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import modelo_Objetos.Filme;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;


 public class ManipulacaoBD {
    
         //aqui eu faço inserções no banco de dados
    public void inserirFilme(Filme filme) {
        Connection conn = ConexaoBD.conectar() ;
        String sqlInserir = "INSERT INTO filmes( nome, "
                                        + "genero, "
                                        + "ano, "
                                        + "duracao) "
                                + "VALUE( '" +filme.getNome()+"', "
                                        + "'"+filme.getGenero()+"', "
                                        + "'"+filme.getAno()+"', "
                                        + "'"+filme.getDuracao()+"')";
        try 
        {
            Statement stm = (Statement) conn.createStatement();
            stm.execute(sqlInserir);            
            System.out.println("Comando executado com sucesso.");
        } 
        catch (SQLException ex) 
        {
          System.out.println("Erro ao executar o comando.");
        } 
        finally 
        {
            ConexaoBD.desconectar(conn);
        }
        
    }
    
     //aqui eu seleciono o todos os filmes do banco e crio uma lista.
    public ArrayList<Filme> listarFilmes() {
        ArrayList<Filme> filmes = new ArrayList<>();
        String sqlBuscar = "SELECT * FROM filmes"; 
        Connection conn = ConexaoBD.conectar(); 
        try 
        {
            Statement stm = (Statement) conn.createStatement();
            ResultSet resultado = stm.executeQuery(sqlBuscar); 
            while(resultado.next()) 
            {
                String idfilme = resultado.getString(1);
                String nome = resultado.getString(2);
                String genero = resultado.getString(3);
                String ano = resultado.getString(4);
                String duracao = resultado.getString(5);
                
                filmes.add(new Filme(idfilme,nome,genero,ano,duracao));
                
            }         
           
        } 
        catch (SQLException ex) 
        {
          System.out.println("Erro ao executar o comando.");
        } 
        finally 
        {
            ConexaoBD.desconectar(conn);
        }
        return filmes;
    }        
    //aqui eu seleciono o filme e enviou para o metodo update. (alterarFilme)
    public void selecionarFilme(Filme Filme){
        
        String sqlSelectId = "SELECT * FROM filmes WHERE idfilme = ?";
        try{
            Connection conn = ConexaoBD.conectar();
            PreparedStatement pst = conn.prepareStatement(sqlSelectId);
            pst.setString(1,Filme.getIdfilme());
            ResultSet rs = pst.executeQuery();
            while(rs.next()){
               Filme.setIdfilme(rs.getString(1));
               Filme.setNome(rs.getString(2));
               Filme.setGenero(rs.getString(3));
               Filme.setAno(rs.getString(4));
               Filme.setDuracao(rs.getString(5));
               conn.close();
            }    
         
        } catch (Exception e){
            System.out.println(e);
            
        }
      
    }
     //aqui eu busco no banco de dados um filme pelo id e trago o mesmo para ser editado.
    public void alterarFilme(Filme Filme){
        String sqlUpdate = "UPDATE filmes SET nome=?, genero=?, ano=?, duracao=? WHERE idfilme=?";
        
        try{
            Connection conn = ConexaoBD.conectar();
            PreparedStatement pst = conn.prepareStatement(sqlUpdate);
            pst.setString(1,Filme.getNome());
            pst.setString(2,Filme.getGenero());
            pst.setString(3,Filme.getAno());
            pst.setString(4,Filme.getDuracao());
            pst.setString(5,Filme.getIdfilme());
            pst.executeUpdate();
            conn.close();
        }catch (Exception e){
            System.out.println(e);
            
        }
        
    }
        //aqui eu busco no banco de dados um filme pelo id e excluou o mesmo.
    public void deletarFilme(Filme Filme){
        String sqlDeletar = "DELETE FROM filmes WHERE idfilme=?";
        
        try{
            Connection conn = ConexaoBD.conectar();
            PreparedStatement pst = conn.prepareStatement(sqlDeletar);
            pst.setString(1,Filme.getIdfilme());
            pst.executeUpdate();
            conn.close();
        }catch (Exception e){
            System.out.println(e);
            
        }
        
    }
    
    
    //aqui eu faço a busca de um filme pelo nome, e crio uma nova lista, para apresentação dos dados.
     public ArrayList<Filme> buscaFilmesPorNome(String nome) {
        ArrayList<Filme> resultados = new ArrayList<>();
        String sqlLike = "SELECT * FROM filmes WHERE nome LIKE ?";
        try (Connection conn = ConexaoBD.conectar();
             PreparedStatement pst = conn.prepareStatement(sqlLike)) {

            pst.setString(1, "%" + nome + "%");
            ResultSet resultado = pst.executeQuery();

            while (resultado.next()) {
                String idfilme = resultado.getString(1);
                String nomeFilme = resultado.getString(2);
                String genero = resultado.getString(3);
                String ano = resultado.getString(4);
                String duracao = resultado.getString(5);

                resultados.add(new Filme(idfilme, nomeFilme, genero, ano, duracao));
            }

        } catch (Exception e){
            System.out.println(e);
        }
        return resultados;
    }
}
