package controle;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.util.ArrayList;
import modelo_BD.ManipulacaoBD;
import modelo_Objetos.Filme;

@WebServlet(name = "MyServlet", urlPatterns = {"/MyServlet"})

public class MyServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        ProcessRequest(request, response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        ProcessRequest(request, response);

    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

    protected void ProcessRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
//aqui recebo os direcionamentos das paginas jsp e encaminho a cada metodo.
        String direcionamento = request.getParameter("direcionamento");
        if (direcionamento != null) {
            switch (direcionamento) {
                case "cadastroFilmes" ->
                    cadastrarFilmes(request, response);
                case "listarFilmes" ->
                    listarFilmes(request, response);
                case "editar" ->
                    editarFilme(request, response);
                case "atualizar" ->
                    atualizarFilme(request, response);
                case "deletar" ->
                    deletarFilme(request, response);
                case "termo" ->
                    buscarFilme(request, response);
                default ->
                    request.getRequestDispatcher("/index.jsp").forward(request, response);
            }
        } else {
            request.getRequestDispatcher("/index.jsp").forward(request, response);
        }

    }
//aqui crio uma sessão e uma lista para o filme q acabou de ser cadastrado e envio para o metodo inserir filme e para o listarfilme
    //ter acesso a lista tambem.
    protected void cadastrarFilmes(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        Filme filme = new Filme(request.getParameter("nome"),
                request.getParameter("genero"),
                request.getParameter("ano"),
                request.getParameter("duracao"));

        HttpSession session = request.getSession();
        session.setAttribute("filme", filme);

        //Salvando no banco
        ManipulacaoBD mBD = new ManipulacaoBD();
        mBD.inserirFilme(filme);

        //Buscando lista de filmes BD
        ArrayList<Filme> lista = (ArrayList<Filme>) mBD.listarFilmes();
        //Atualizando a lista de filmes na sessão
        session.setAttribute("listarFilmes", lista);
        System.out.println(lista.size());
        request.getRequestDispatcher("/respostaCadastroFilme.jsp").forward(request, response);
    }
//aqui crio a lista que foi alimentada no cadastro de filmes e mando para o metodo listarfilmes para ser adicionado ao banco.
    protected void listarFilmes(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ManipulacaoBD manipulacaoBD = new ManipulacaoBD();
        ArrayList<Filme> lista = manipulacaoBD.listarFilmes();
        request.setAttribute("filme", lista);
        request.getRequestDispatcher("/listarFilmes.jsp").forward(request, response);
    }
//aqui eu recebo o filme pelo seu id e envio para o metodo selecionarFilme no manipulaçãoBD
    protected void editarFilme(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Filme filme = new Filme(request.getParameter("nome"),
                request.getParameter("genero"),
                request.getParameter("ano"),
                request.getParameter("duracao"));

        String idfilme = request.getParameter("idfilme");
        filme.setIdfilme(idfilme);

        ManipulacaoBD manipulacaoBD = new ManipulacaoBD();
        manipulacaoBD.selecionarFilme(filme);

        request.setAttribute("idfilme", filme.getIdfilme());
        request.setAttribute("nome", filme.getNome());
        request.setAttribute("genero", filme.getGenero());
        request.setAttribute("ano", filme.getAno());
        request.setAttribute("duracao", filme.getDuracao());

        request.getRequestDispatcher("/editarFilme.jsp").forward(request, response);
    }
//aqui eu recebo o filme pelo seu id e envio para o metodo alterarFilme no manipulaçãoBD
    protected void atualizarFilme(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Filme filme = new Filme(request.getParameter("nome"),
                request.getParameter("genero"),
                request.getParameter("ano"),
                request.getParameter("duracao"));

        filme.setIdfilme(request.getParameter("idfilme"));
        filme.setNome(request.getParameter("nome"));
        filme.setGenero(request.getParameter("genero"));
        filme.setAno(request.getParameter("ano"));
        filme.setDuracao(request.getParameter("duracao"));

        ManipulacaoBD manipulacaoBD = new ManipulacaoBD();
        manipulacaoBD.alterarFilme(filme);

        request.getRequestDispatcher("/MyServlet?direcionamento=listarFilmes").forward(request, response);

    }
//aqui eu recebo o filme pelo seu id e envio para o metodo deletar filme no manipulaçãoBD
    protected void deletarFilme(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idfilme = request.getParameter("idfilme");
        Filme filme = new Filme(request.getParameter("nome"),
                request.getParameter("genero"),
                request.getParameter("ano"),
                request.getParameter("duracao"));
        filme.setIdfilme(idfilme);

        ManipulacaoBD manipulacaoBD = new ManipulacaoBD();
        manipulacaoBD.deletarFilme(filme);

        request.getRequestDispatcher("/MyServlet?direcionamento=listarFilmes").forward(request, response);
    }
     //aqui eu recebo o nome do filme digitado pelo usuario e envio para o metodo buscaFilmes la no manipulaçãoBD.
    protected void buscarFilme(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

         String nomeFilme = request.getParameter("nome");

       ManipulacaoBD manipulacaoBD = new ManipulacaoBD();
        ArrayList<Filme> resultados = manipulacaoBD.buscaFilmesPorNome(nomeFilme);

        request.setAttribute("resultados", resultados);
        
       request.getRequestDispatcher("/resultadoBusca.jsp").forward(request, response);
    }
}
