/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo_Objetos;

/**
 *
 * @author Jaime Reis
 */
public class Filme {
   
    private String idfilme;
    private String nome;
    private String genero;
    private String ano;
    private String duracao;
   
    public Filme ( String nome, 
                   String genero, 
                   String ano, 
                   String duracao)
    {
        this.nome = nome;
        this.genero = genero;
        this.ano = ano;
        this.duracao = duracao;
    }
    
    public Filme(   
                   String idfilme,
                   String nome, 
                   String genero, 
                   String ano, 
                   String duracao)
    {
        this.idfilme = idfilme;
        this.nome = nome;
        this.genero = genero;
        this.ano = ano;
        this.duracao = duracao;
    }

    /**
     * @return the idfilme
     */
    public String getIdfilme() {
        return idfilme;
    }

    /**
     * @param idfilme the idfilme to set
     */
    public void setIdfilme(String idfilme) {
        this.idfilme = idfilme;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the genero
     */
    public String getGenero() {
        return genero;
    }

    /**
     * @param genero the genero to set
     */
    public void setGenero(String genero) {
        this.genero = genero;
    }

    /**
     * @return the ano
     */
    public String getAno() {
        return ano;
    }

    /**
     * @param ano the ano to set
     */
    public void setAno(String ano) {
        this.ano = ano;
    }

    /**
     * @return the duracao
     */
    public String getDuracao() {
        return duracao;
    }

    /**
     * @param duracao the duracao to set
     */
    public void setDuracao(String duracao) {
        this.duracao = duracao;
    }

}